'use strict';


/**
 * Analisa críticas contidas em um arquivo de áudio ou em um texto e recomenda um carro da FCA dependendo das críticas.
 * 
 *
 * car String Nome do carro sobre o qual o comentário ou crítica é feito.
 * text String Texto contendo uma crítica ou comentário sobre um carro. (optional)
 * audio File Áudio em formato FLAC contendo uma crítica ou comentário sobre um carro. (optional)
 * returns Result
 **/
exports.apiRecommendPOST = function(car,text,audio) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "entities" : [ {
    "sentiment" : -0.95,
    "entity" : "desempenho",
    "mention" : "motor"
  }, {
    "sentiment" : -0.95,
    "entity" : "desempenho",
    "mention" : "motor"
  } ],
  "recommendation" : "Fiat Argo"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

